﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pr20
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Button1.Content = "->";
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            string str1 = TxbTextB1.Text; string str2 = TxbTextB2.Text;
            TxbTextB1.Text = str2; TxbTextB2.Text = str1;
            if (Button1.Content == "->") Button1.Content = "<-";
            else Button1.Content = "->";
        }

        private void Transform_Click(object sender, RoutedEventArgs e)
        {
            int chislo1 = Convert.ToInt32(TxbCalc1.Text);
            int chislo2 = Convert.ToInt32(TxbCalc2.Text);
            int TxbSumma1 = chislo1 + chislo2;
            int TxbMinus2 = chislo1 - chislo2;
            int TxbYmnosh3 = chislo1 * chislo2;
            int TxbDelenie4 = chislo1 / chislo2;
            string Txbsumma = Convert.ToString(TxbSumma1);
            string Txbminus = Convert.ToString(TxbMinus2);
            string Txbymnosh = Convert.ToString(TxbYmnosh3);
            string Txbdelenie = Convert.ToString(TxbDelenie4);
            TxbSumma.Text = Txbsumma;
            TxbMinus.Text = Txbminus;
            TxbYmnosh.Text = Txbymnosh;
            TxbDelenie.Text = Txbdelenie;
        }

        private void Cbx1_Click(object sender, RoutedEventArgs e)
        {
            //TxbCH1.Visibility = false;
            TxbCH1.Visibility = Visibility.Hidden;
            
        }

        private void Cbx2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Cbx3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Cbx1_Checked(object sender, RoutedEventArgs e)
        {
            TxbCH1.Visibility = Visibility.Visible;
        }

        private void Cbx1_Unchecked(object sender, RoutedEventArgs e)
        {
            TxbCH1.Visibility = Visibility.Hidden;
        }

        private void Cbx1_Click_1(object sender, RoutedEventArgs e)
        {
          
        }

        private void Cbx2_Checked(object sender, RoutedEventArgs e)
        {
            TxbCH2.Visibility = Visibility.Visible;
        }

        private void Cbx2_Unchecked(object sender, RoutedEventArgs e)
        {
            TxbCH2.Visibility = Visibility.Hidden;
        }

        private void Cbx3_Checked(object sender, RoutedEventArgs e)
        {
            TxbCH3.Visibility = Visibility.Visible;
        }

        private void Cbx3_Unchecked(object sender, RoutedEventArgs e)
        {
            TxbCH3.Visibility = Visibility.Hidden;
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            int chislo11 = Convert.ToInt32(TxbZ1.Text);
            int chislo22 = Convert.ToInt32(TxbZ2.Text);
            int summavar = chislo11 + chislo22;
            string summafin = Convert.ToString(summavar);
            TxbZ3.Text = summafin;
        }

        private void minus_Click(object sender, RoutedEventArgs e)
        {
            int chislo11 = Convert.ToInt32(TxbZ1.Text);
            int chislo22 = Convert.ToInt32(TxbZ2.Text);
            int minusvar = chislo11 - chislo22;
            string minusfin = Convert.ToString(minusvar);
            TxbZ3.Text = minusfin;
        }

        private void umnozh_Click(object sender, RoutedEventArgs e)
        {
            int chislo11 = Convert.ToInt32(TxbZ1.Text);
            int chislo22 = Convert.ToInt32(TxbZ2.Text);
            int umonzhvar = chislo11 * chislo22;
            string umnozhfin = Convert.ToString(umonzhvar);
            TxbZ3.Text = umnozhfin;
        }
        private void Rb1blue_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Blue,FirstColor);
        }

        private void Setcolor(Color color,TextBox textBox)
        {
            LinearGradientBrush myBrush = new LinearGradientBrush();
            myBrush.GradientStops.Add(new GradientStop(color, 1.1));
            textBox.Background = myBrush;
        }

        private void Rb1Red_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Red, FirstColor);
        }

        private void Rb1Green_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Green, FirstColor);
        }

        private void Rb2blue_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Blue, SecondColor);
        }

        private void Rb2Red_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Red, SecondColor);
        }

        private void Rb2Green_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Green, SecondColor);
        }

        private void Rb3blue_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Blue, ThirdColor);
        }

        private void Rb3Red_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Red, ThirdColor);
        }

        private void Rb3Green_Checked(object sender, RoutedEventArgs e)
        {
            Setcolor(Colors.Green, ThirdColor);
        }
    }
}
