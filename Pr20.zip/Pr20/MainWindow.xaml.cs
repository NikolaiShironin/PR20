﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pr20
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Button1.Content = "->";
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            string str1 = TxbTextB1.Text; string str2 = TxbTextB2.Text;
            TxbTextB1.Text = str2; TxbTextB2.Text = str1;
            if (Button1.Content == "->") Button1.Content = "<-";
            else Button1.Content = "->";
        }

        private void Transform_Click(object sender, RoutedEventArgs e)
        {
            int chislo1 = Convert.ToInt32(TxbCalc1.Text);
            int chislo2 = Convert.ToInt32(TxbCalc2.Text);
            int TxbSumma1 = chislo1 + chislo2;
            int TxbMinus2 = chislo1 - chislo2;
            int TxbYmnosh3 = chislo1 * chislo2;
            int TxbDelenie4 = chislo1 / chislo2;
            string Txbsumma = Convert.ToString(TxbSumma1);
            string Txbminus = Convert.ToString(TxbMinus2);
            string Txbymnosh = Convert.ToString(TxbYmnosh3);
            string Txbdelenie = Convert.ToString(TxbDelenie4);
            TxbSumma.Text = Txbsumma;
            TxbMinus.Text = Txbminus;
            TxbYmnosh.Text = Txbymnosh;
            TxbDelenie.Text = Txbdelenie;
        }

        private void Cbx1_Click(object sender, RoutedEventArgs e)
        {
            //TxbCH1.Visibility = false;
            TxbCH1.Visibility = Visibility.Hidden;
            
        }

        private void Cbx2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Cbx3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Cbx1_Checked(object sender, RoutedEventArgs e)
        {
            TxbCH1.Visibility = Visibility.Hidden;
        }

        private void Cbx1_Unchecked(object sender, RoutedEventArgs e)
        {
            TxbCH1.Visibility = Visibility.Visible;
        }
    }
}
